<!-- footer -->

<div class="footer" align=center >

	<table align=center>
    <tr>

    	<td valign='top'>
			<A href="sucursales.php?action=lista">Mis compras</A>
    	</td>
    	<td valign='top'>
			<A href="sucursales.php?action=lista">Mis compras</A>
    	</td>
    	<td valign='top'>
			<A href="sucursales.php?action=lista">Mis compras</A>
    	</td>
	
    </tr>

    </table>
	
   	<!--<a href="http://www.caffeina.mx">Página principal de Caffeina</a> - <a href="http://www.caffeina.mx/report/">Reportar una falla</a> - <a href="http://www.caffeina.mx/contacto.php">Envíenos un mensaje</a>-->
    <br>
	<div align=center style="padding-bottom: 10px;">
		 <a href="http://caffeina.mx/"><img src='../media/logo_simbolo.jpg'></a> <br>
		<br>
    	©2010 Caffeina Mexico 

		<!--		 <img src='../media/banners/LOGO-SUP-FAC.jpg'> -->
	</div>

</div>
