<!-- footer -->

<div class="footer" align=center >
	<!--
	<table align=center>
    <tr>

    	<td valign='top'>
			<a>SUCURSALES</a>
			<UL   >
				<LI><A href="sucursales.php?action=lista">Sucursales</A></LI>
				<li>
				  <a href="inventario.php?action=surtir">Surtir Sucursal</a>
				</li>

				<LI><A href="sucursales.php?action=ventas">Ventas a sucursales</A></LI>
				<LI><A href="gerentes.php?action=lista">Gerentes</A></LI>

				<LI class="last"><A href="gerentes.php?action=nuevo">Nuevo gerente</A></LI>
			</UL>
    	</td>
		<td valign='top'>
			<A >VENTAS</A>
				<ul >
				<li >
				  <a  href="ventas.php?action=vender">Realizar venta</a>
				</li>
				<li>
				  <a  href="ventas.php?action=lista">Ver ventas</a>
				</li>

			  </ul>
    	</td>

		<td valign='top'>
			<A >PROVEEDORES</A>
		  <ul >
			<li >
			  <a href="proveedor.php?action=lista">Lista de proveedores</a>
			</li>
			<li>
			  <a href="proveedor.php?action=nuevo">Nuevo proveedor</a>
			</li>
			<li>
			  <a href="proveedor.php?action=abastecer">Abastecerse de proveedor</a>
			</li>
			<li>
			  <a href="proveedor.php?action=compras_lista">Compras a proveedor</a>
			</li>			

		  </ul>
    	</td>
		<td valign='top'>
			<A >INVENTARIO</A>
			  <ul >
				<li >
				  <a href="inventario.php?action=maestro">Inventario maestro</a>
				</li>      
				<li >
				  <a href="inventario.php?action=lista">Inventario de sucursales</a>
				</li>

				<li>
				  <a href="inventario.php?action=nuevo">Nuevo Producto</a>
				</li>
				<li>
				  <a href="inventario.php?action=transit">En transito</a>
				</li>
			  </ul>
		</td>
    </tr>

    </table>
	-->
   	<!--<a href="http://www.caffeina.mx">Página principal de Caffeina</a> - <a href="http://www.caffeina.mx/report/">Reportar una falla</a> - <a href="http://www.caffeina.mx/contacto.php">Envíenos un mensaje</a>-->
    <br>
	<div align=center style="padding-bottom: 10px;">
		 <img src='../media/logo_simbolo.jpg'> <br>
		<br>
    	©2010 Caffeina Mexico 

		<!--		 <img src='../media/banners/LOGO-SUP-FAC.jpg'> -->
	</div>

</div>
