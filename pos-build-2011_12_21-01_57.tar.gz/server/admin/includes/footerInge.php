<!-- footer -->

<div class="footer" align=center >

	


	<div align=center style="padding-bottom: 10px;">
		 <img src='../media/logo_simbolo.png'> <br>
    ©2010 Caffeina Mexico 
	</div>

</div>
