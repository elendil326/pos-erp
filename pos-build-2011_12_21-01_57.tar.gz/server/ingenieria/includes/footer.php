<p class="footer">
  ©2010 Caffeina - <a href="">Página principal de Caffeina</a> - <a href="">Condiciones del servicio</a> - <a href="">Política de privacidad</a> - <a href="">Envíenos un mensaje</a>
</p>