<?php

require_once ('Estructura.php');
require_once("base/gastos_fijos.dao.base.php");
require_once("base/gastos_fijos.vo.base.php");
/** Page-level DocBlock .
  * 
  * @author Anonymous
  * @package docs
  * 
  */
/** GastosFijos Data Access Object (DAO).
  * 
  * Esta clase contiene toda la manipulacion de bases de datos que se necesita para 
  * almacenar de forma permanente y recuperar instancias de objetos {@link GastosFijos }. 
  * @author Anonymous
  * @access public
  * @package docs
  * 
  */
class GastosFijosDAO extends GastosFijosDAOBase
{

}
