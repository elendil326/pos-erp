<?php 

interface GuiComponent{
	

	function renderCmp();


}