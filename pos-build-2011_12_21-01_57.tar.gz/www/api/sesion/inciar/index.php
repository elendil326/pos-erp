<?php


$apiHandler = new NewContest();
$apiHandler->ExecuteApi();