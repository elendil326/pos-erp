<?php

	define("I_AM_SUCURSAL", true);
	
	require_once( "../../server/bootstrap.php" );

	Logger::log(">> sucursal/index.php <<");
	
?><html>
<head>
	<title>Punto de Venta</title>
	

    <link rel="stylesheet" href="http://api.caffeina.mx/sencha-latest/resources/css/sencha-touch.css" type="text/css">
    <script type="text/javascript" src="http://api.caffeina.mx/sencha-latest/sencha-touch.js"></script>

	<link rel="stylesheet" type="text/css" href="../getResource.php?mod=login&type=css">
	<link rel="stylesheet" type="text/css" href="../getResource.php?mod=shared&type=css">	
	
	<script type="text/javascript" src="../getResource.php?mod=login&type=js"></script>
	<script type="text/javascript" src="../getResource.php?mod=shared&type=js"></script>
</head>
<body>
	


</body>
</html>
